Oidc.Log.logger = console;
Oidc.Log.level = Oidc.Log.INFO;
// can pass true param and will keep popup window open
new Oidc.UserManager().signoutPopupCallback();
