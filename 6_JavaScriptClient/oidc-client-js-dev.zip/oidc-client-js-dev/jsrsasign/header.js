/*
 * jsrsasign(all) 8.0.12 (2018-04-22) (c) 2010-2018 Kenji Urushima | kjur.github.com/jsrsasign/license
 */

var navigator = {};
navigator.userAgent = false;

var window = {};
